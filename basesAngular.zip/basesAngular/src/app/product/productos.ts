export interface Productos {
    productoId:number,
      Modelo:string,
      Descripcion:string,
      Precio:number,
      Year:string,
      Marca:string,
      Color:string,
      ImagenUrl:string
}